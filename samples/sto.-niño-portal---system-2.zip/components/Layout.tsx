import React, { ReactNode, useState } from 'react';
import { Role } from '../types';

interface LayoutProps {
  children: ReactNode;
  role: Role;
  setRole: (role: Role) => void;
  currentView: string;
  setView: (view: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, role, setRole, currentView, setView }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <aside className={`bg-slate-900 text-white w-64 flex-shrink-0 transition-all duration-300 ${isSidebarOpen ? 'ml-0' : '-ml-64'} fixed h-full z-20 print:hidden`}>
        <div className="p-6 border-b border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center font-bold">SN</div>
          <h1 className="font-bold text-lg">Sto. Niño Portal</h1>
        </div>

        <nav className="p-4 space-y-2">
          {role === Role.STUDENT && (
            <>
              <button 
                onClick={() => setView('sf9')}
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${currentView === 'sf9' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/></svg>
                SF9 Viewer
              </button>
              <button 
                onClick={() => setView('id')}
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${currentView === 'id' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                Student ID
              </button>
            </>
          )}

          {role === Role.TEACHER && (
            <>
              <button 
                onClick={() => setView('grading')}
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${currentView === 'grading' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="M18.7 8l-5.1 5.2-2.8-2.7L7 14.3"/></svg>
                Grading Sheet
              </button>
              <button 
                onClick={() => setView('masterlist')}
                className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${currentView === 'masterlist' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Masterlist
              </button>
            </>
          )}
        </nav>

        <div className="absolute bottom-0 w-full p-4 border-t border-slate-800">
            <div className="flex items-center gap-3 mb-4">
                <img src="https://picsum.photos/40/40" alt="Profile" className="w-10 h-10 rounded-full border border-slate-600" />
                <div>
                    <p className="text-sm font-bold">{role === Role.STUDENT ? 'Carlo Dela Cruz' : 'Mrs. Santos'}</p>
                    <p className="text-xs text-slate-400">{role}</p>
                </div>
            </div>
            <button 
                onClick={() => setRole(role === Role.STUDENT ? Role.TEACHER : Role.STUDENT)}
                className="w-full bg-slate-800 hover:bg-slate-700 text-xs py-2 rounded text-slate-300 transition-colors">
                Switch Role (Demo)
            </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 ${isSidebarOpen ? 'ml-64' : 'ml-0'} print:ml-0`}>
        {/* Top Navbar */}
        <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-6 sticky top-0 z-10 print:hidden">
            <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="text-gray-500 hover:text-gray-800">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
            </button>
            <div className="flex items-center gap-4">
                <button className="p-2 text-gray-400 hover:text-gray-600">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                </button>
            </div>
        </header>

        <div className="p-8 print:p-0">
            {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;