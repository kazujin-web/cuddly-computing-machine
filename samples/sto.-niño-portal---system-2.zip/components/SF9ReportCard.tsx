import React from 'react';
import { SF9Data } from '../types';

interface SF9ReportCardProps {
  data: SF9Data;
}

const SF9ReportCard: React.FC<SF9ReportCardProps> = ({ data }) => {
  return (
    <div className="bg-gray-200 p-8 print:p-0 overflow-auto h-[calc(100vh-64px)]">
      <div className="mx-auto w-fit print:w-full">
        
        {/* FRONT & BACK PAGE */}
        <div className="bg-white shadow-lg print:shadow-none w-[11in] h-[8.5in] flex mb-8 print:mb-0 print:break-after-page text-[10pt] font-serif leading-tight overflow-hidden relative">
          
          {/* LEFT PANEL (BACK PAGE) - Attendance & Signature */}
          <div className="w-1/2 p-8 border-r border-gray-400 relative">
            <h3 className="text-center font-bold mb-2">REPORT ON ATTENDANCE</h3>
            <table className="w-full border-collapse border border-black text-center text-[9pt]">
              <thead>
                <tr>
                  <th className="border border-black p-1"></th>
                  {data.attendance.map((rec, i) => (
                    <th key={i} className="border border-black p-1">{rec.month.substring(0,3)}</th>
                  ))}
                  <th className="border border-black p-1">Total</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-black p-1 text-left font-bold whitespace-nowrap">No. of school days</td>
                  {data.attendance.map((rec, i) => (
                    <td key={i} className="border border-black p-1">{rec.schoolDays}</td>
                  ))}
                  <td className="border border-black p-1 font-bold">100</td>
                </tr>
                <tr>
                  <td className="border border-black p-1 text-left font-bold whitespace-nowrap">No. of days present</td>
                  {data.attendance.map((rec, i) => (
                    <td key={i} className="border border-black p-1">{rec.daysPresent}</td>
                  ))}
                  <td className="border border-black p-1 font-bold">90</td>
                </tr>
                <tr>
                  <td className="border border-black p-1 text-left font-bold whitespace-nowrap">No. of days absent</td>
                  {data.attendance.map((rec, i) => (
                    <td key={i} className="border border-black p-1">{rec.daysAbsent}</td>
                  ))}
                  <td className="border border-black p-1 font-bold">10</td>
                </tr>
              </tbody>
            </table>

            <div className="mt-6 text-[10pt] italic space-y-2 font-sans">
              <p><strong>Dear Parent:</strong></p>
              <p className="indent-8 text-justify">This report card shows the ability and progress your child has made in the different learning areas as well as his/her core values.</p>
              <p className="indent-8 text-justify">The school welcomes you if you desire to know more about your child's progress.</p>
            </div>

            <div className="mt-8 text-center">
              <h4 className="font-bold text-[11pt] mb-4">PARENT'S/GUARDIAN'S SIGNATURE</h4>
              <div className="grid grid-cols-4 gap-4 text-center text-[9pt]">
                 <div>
                    <div className="border-b border-black h-6"></div>
                    <div>1st QUARTER</div>
                 </div>
                 <div>
                    <div className="border-b border-black h-6"></div>
                    <div>2nd QUARTER</div>
                 </div>
                 <div>
                    <div className="border-b border-black h-6"></div>
                    <div>3rd QUARTER</div>
                 </div>
                 <div>
                    <div className="border-b border-black h-6"></div>
                    <div>4th QUARTER</div>
                 </div>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t-2 border-black">
               <h4 className="font-bold text-center text-[11pt] mb-2">Certificate of Transfer</h4>
               <div className="flex justify-between text-[10pt] mb-1">
                  <div>Admitted to Grade: <strong>FIVE</strong></div>
                  <div>Section: <strong>RIZAL</strong></div>
               </div>
               <div className="flex justify-between text-[10pt] mb-8">
                  <div>Eligibility for Admission to Grade:</div>
                  <div>_______</div>
               </div>
               <div className="flex justify-between text-[10pt] items-end px-4">
                  <div className="text-center">
                      <div className="font-bold uppercase">Mrs. Santos</div>
                      <div className="border-t border-black w-40 mx-auto">Teacher</div>
                  </div>
                  <div className="text-center">
                      <div className="font-bold uppercase">Mr. Principal</div>
                      <div className="border-t border-black w-40 mx-auto">Principal</div>
                  </div>
               </div>
               <div className="mt-4 text-[10pt]">
                   <strong>Cancellation of Eligibility to Transfer</strong><br/>
                   Admitted in: ____________________ Date: _________
               </div>
               <div className="text-right mt-4 px-8">
                   <div className="border-b border-black w-40 inline-block"></div>
                   <div className="mr-12">Principal</div>
               </div>
            </div>
          </div>

          {/* RIGHT PANEL (FRONT PAGE) - Student Info */}
          <div className="w-1/2 p-8 flex flex-col items-center">
            <div className="text-center w-full mb-8">
                <h4 className="text-[10pt]">Republic of the Philippines</h4>
                <h2 className="text-[14pt] font-bold uppercase">Department of Education</h2>
                <h3 className="text-[11pt] font-bold">National Capital Region</h3>
                <h3 className="text-[11pt] font-bold">Division of Parañaque City</h3>
                <h3 className="text-[11pt]">2nd District</h3>
                <h1 className="text-[16pt] font-bold uppercase mt-4 mb-1">Sto. Niño Elementary School</h1>
                <p className="text-[10pt]">School ID : <span className="font-bold">123456</span></p>
            </div>

            <div className="w-full flex-grow flex flex-col justify-center">
                <h2 className="text-[16pt] font-bold text-center mb-8 uppercase tracking-wider">Learner's Progress Report Card</h2>
                
                <div className="grid grid-cols-[auto_1fr] gap-x-2 gap-y-4 text-[11pt] w-full max-w-md mx-auto">
                    <div className="font-bold text-right pr-2">Name:</div>
                    <div className="border-b border-black font-bold uppercase pl-2">{data.student.name}</div>
                    
                    <div className="grid grid-cols-[auto_1fr_auto_1fr] gap-2 col-span-2">
                        <div className="font-bold text-right">Age:</div>
                        <div className="border-b border-black text-center">{data.student.age}</div>
                        <div className="font-bold text-right">Sex:</div>
                        <div className="border-b border-black text-center">{data.student.gender}</div>
                    </div>

                    <div className="grid grid-cols-[auto_1fr_auto_1fr] gap-2 col-span-2">
                        <div className="font-bold text-right">Grade:</div>
                        <div className="border-b border-black text-center">{data.student.gradeLevel}</div>
                        <div className="font-bold text-right">Section:</div>
                        <div className="border-b border-black text-center uppercase">{data.student.section}</div>
                    </div>

                    <div className="font-bold text-right pr-2">School Year:</div>
                    <div className="border-b border-black text-center font-bold">{data.schoolYear}</div>

                    <div className="font-bold text-right pr-2">LRN:</div>
                    <div className="border-b border-black font-bold tracking-widest pl-2">{data.student.lrn}</div>
                </div>
            </div>
          </div>
        </div>

        {/* INSIDE PAGE */}
        <div className="bg-white shadow-lg print:shadow-none w-[11in] h-[8.5in] flex print:break-after-page text-[10pt] font-serif leading-tight overflow-hidden">
          
          {/* LEFT PANEL - Grades */}
          <div className="w-1/2 p-8 border-r border-gray-400">
            <h3 className="text-center font-bold mb-2">REPORT ON LEARNING PROGRESS AND ACHIEVEMENT</h3>
            <table className="w-full border-collapse border border-black text-center text-[9pt]">
              <thead>
                <tr className="bg-gray-100">
                  <th rowSpan={2} className="border border-black p-2 text-left w-1/3">Learning Areas</th>
                  <th colSpan={4} className="border border-black p-1">QUARTER</th>
                  <th rowSpan={2} className="border border-black p-1 w-12">Final Grade</th>
                  <th rowSpan={2} className="border border-black p-1">Remarks</th>
                </tr>
                <tr className="bg-gray-100">
                  <th className="border border-black p-1 w-8">1</th>
                  <th className="border border-black p-1 w-8">2</th>
                  <th className="border border-black p-1 w-8">3</th>
                  <th className="border border-black p-1 w-8">4</th>
                </tr>
              </thead>
              <tbody>
                {data.grades.map((grade, i) => (
                  <React.Fragment key={i}>
                    {grade.subject === "MAPEH" ? (
                        <>
                            <tr className="font-bold">
                                <td className="border border-black p-1 text-left">MAPEH</td>
                                <td className="border border-black p-1">{grade.q1}</td>
                                <td className="border border-black p-1">{grade.q2}</td>
                                <td className="border border-black p-1">{grade.q3}</td>
                                <td className="border border-black p-1">{grade.q4}</td>
                                <td className="border border-black p-1">{grade.final}</td>
                                <td className="border border-black p-1">{grade.remarks}</td>
                            </tr>
                        </>
                    ) : grade.subject === "Music" || grade.subject === "Arts" || grade.subject === "PE" || grade.subject === "Health" ? (
                        <tr className="italic">
                            <td className="border border-black p-1 text-left pl-6">{grade.subject}</td>
                            <td className="border border-black p-1">{grade.q1}</td>
                            <td className="border border-black p-1">{grade.q2}</td>
                            <td className="border border-black p-1">{grade.q3}</td>
                            <td className="border border-black p-1">{grade.q4}</td>
                            <td className="border border-black p-1">{grade.final}</td>
                            <td className="border border-black p-1">{grade.remarks}</td>
                        </tr>
                    ) : (
                        <tr>
                            <td className="border border-black p-1 text-left font-semibold">{grade.subject}</td>
                            <td className="border border-black p-1">{grade.q1}</td>
                            <td className="border border-black p-1">{grade.q2}</td>
                            <td className="border border-black p-1">{grade.q3}</td>
                            <td className="border border-black p-1">{grade.q4}</td>
                            <td className="border border-black p-1 font-bold">{grade.final}</td>
                            <td className="border border-black p-1">{grade.remarks}</td>
                        </tr>
                    )}
                  </React.Fragment>
                ))}
                <tr>
                  <td colSpan={5} className="border border-black p-1 text-right font-bold pr-4">General Average</td>
                  <td className="border border-black p-1 font-bold text-red-600">82</td>
                  <td className="border border-black p-1 font-bold">Passed</td>
                </tr>
              </tbody>
            </table>
            
            <div className="mt-6 flex justify-between text-[9pt]">
                <div className="w-1/2">
                    <div className="font-bold mb-1">Descriptors</div>
                    <div>Outstanding</div>
                    <div>Very Satisfactory</div>
                    <div>Satisfactory</div>
                    <div>Fairly Satisfactory</div>
                    <div>Did Not Meet Expectations</div>
                </div>
                <div className="w-1/2">
                    <div className="font-bold mb-1">Grading Scale</div>
                    <div className="text-center">90-100</div>
                    <div className="text-center">85-89</div>
                    <div className="text-center">80-84</div>
                    <div className="text-center">75-79</div>
                    <div className="text-center">Below 75</div>
                </div>
                <div className="w-1/3">
                    <div className="font-bold mb-1">Remarks</div>
                    <div className="text-center">Passed</div>
                    <div className="text-center">Passed</div>
                    <div className="text-center">Passed</div>
                    <div className="text-center">Passed</div>
                    <div className="text-center">Failed</div>
                </div>
            </div>
          </div>

          {/* RIGHT PANEL - Values */}
          <div className="w-1/2 p-8">
            <h3 className="text-center font-bold mb-2">REPORT ON LEARNER'S OBSERVED VALUES</h3>
            <table className="w-full border-collapse border border-black text-center text-[9pt]">
              <thead>
                <tr className="bg-gray-100">
                  <th rowSpan={2} className="border border-black p-1 w-1/5">Core Values</th>
                  <th rowSpan={2} className="border border-black p-1">Behavior Statements</th>
                  <th colSpan={4} className="border border-black p-1">Quarter</th>
                </tr>
                <tr className="bg-gray-100">
                  <th className="border border-black p-1 w-8">1</th>
                  <th className="border border-black p-1 w-8">2</th>
                  <th className="border border-black p-1 w-8">3</th>
                  <th className="border border-black p-1 w-8">4</th>
                </tr>
              </thead>
              <tbody>
                {data.values.map((val, i) => (
                  <React.Fragment key={i}>
                      {val.behaviorStatements.map((stmt, j) => (
                        <tr key={`${i}-${j}`}>
                            {j === 0 && (
                                <td rowSpan={val.behaviorStatements.length} className="border border-black p-1 font-bold align-middle uppercase">{val.value}</td>
                            )}
                            <td className="border border-black p-1 text-left align-middle px-2">
                                {stmt}
                            </td>
                            <td className="border border-black p-1 align-middle">{val.q1}</td>
                            <td className="border border-black p-1 align-middle">{val.q2}</td>
                            <td className="border border-black p-1 align-middle">{val.q3}</td>
                            <td className="border border-black p-1 align-middle">{val.q4}</td>
                        </tr>
                      ))}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
            
            <div className="mt-6">
                <div className="font-bold text-[10pt] mb-2">Marking / Non-numerical Rating</div>
                <div className="grid grid-cols-2 text-[9pt]">
                    <div>AO - Always Observed</div>
                    <div>RO - Rarely Observed</div>
                    <div>SO - Sometimes Observed</div>
                    <div>NO - Not Observed</div>
                </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default SF9ReportCard;