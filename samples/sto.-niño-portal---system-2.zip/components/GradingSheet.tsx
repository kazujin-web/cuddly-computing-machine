import React, { useState } from 'react';
import { mockClassRecord } from '../services/mockData';
import { ClassRecord, StudentFullYearGrades } from '../types';

const GradingSheet: React.FC = () => {
  const [data, setData] = useState<ClassRecord>(mockClassRecord);
  const [activeTab, setActiveTab] = useState<'info' | 'q1' | 'q2' | 'q3' | 'q4' | 'final'>('q1');

  // Helper to handle data changes - simplified for demo
  const handleChange = (studentIndex: number, path: string, value: string) => {
    const newData = { ...data };
    // Deep update logic would go here
    setData(newData);
  };

  const TabButton = ({ id, label }: { id: typeof activeTab, label: string }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`px-6 py-2 text-sm font-medium border-b-2 transition-colors ${
        activeTab === id 
          ? 'border-blue-600 text-blue-600 bg-blue-50' 
          : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="bg-white rounded-lg shadow-sm h-full flex flex-col overflow-hidden">
      {/* Toolbar */}
      <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
        <div>
            <h2 className="text-xl font-bold text-gray-800 uppercase tracking-tight">E-Class Record</h2>
            <p className="text-xs text-gray-500">SY {data.schoolYear} • Grade {data.gradeLevel} - {data.section}</p>
        </div>
        <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-green-700 bg-white border border-green-300 rounded shadow-sm hover:bg-green-50">
                Download XLSX
            </button>
            <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-blue-700 bg-white border border-blue-300 rounded shadow-sm hover:bg-blue-50">
                Sync to Google Sheets
            </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 bg-white overflow-x-auto">
        <TabButton id="info" label="Class Info" />
        <TabButton id="q1" label="Quarter 1" />
        <TabButton id="q2" label="Quarter 2" />
        <TabButton id="q3" label="Quarter 3" />
        <TabButton id="q4" label="Quarter 4" />
        <TabButton id="final" label="Final Summary" />
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto p-4 bg-gray-100">
        <div className="bg-white shadow-sm border border-gray-300 min-h-[600px] overflow-auto">
            {activeTab === 'info' && <ClassInfoTable data={data} />}
            {(activeTab === 'q1' || activeTab === 'q2' || activeTab === 'q3' || activeTab === 'q4') && (
                <QuarterlyTable data={data} quarter={activeTab} />
            )}
            {activeTab === 'final' && <FinalSummaryTable data={data} />}
        </div>
      </div>
    </div>
  );
};

// --- Sub-components for specific table layouts ---

const ClassInfoTable = ({ data }: { data: ClassRecord }) => (
  <table className="w-full text-sm border-collapse min-w-[1000px]">
    <thead>
        <tr>
            <th className="border border-gray-400 bg-white p-2 text-center font-bold">Names</th>
            <th className="border border-gray-400 bg-white p-2 text-center font-bold">LRN</th>
            <th className="border border-gray-400 bg-white p-2 text-center font-bold">Sex</th>
            <th className="border border-gray-400 bg-white p-2 text-center font-bold">Age</th>
            <th className="border border-gray-400 bg-white p-2 text-center font-bold">Q1 BEHAVIOR</th>
            <th className="border border-gray-400 bg-white p-2 text-center font-bold">Q2</th>
            <th className="border border-gray-400 bg-white p-2 text-center font-bold">Q3</th>
            <th className="border border-gray-400 bg-white p-2 text-center font-bold">Q4</th>
        </tr>
    </thead>
    <tbody>
        {data.students.map((student) => (
            <tr key={student.studentId}>
                <td className="border border-gray-300 p-1 px-2">{student.studentName}</td>
                <td className="border border-gray-300 p-1 text-center">{student.lrn}</td>
                <td className="border border-gray-300 p-1 text-center">{student.sex === 'M' ? 'MALE' : 'FEMALE'}</td>
                <td className="border border-gray-300 p-1 text-center">{student.age}</td>
                <td className="border border-gray-300 p-1"></td>
                <td className="border border-gray-300 p-1"></td>
                <td className="border border-gray-300 p-1"></td>
                <td className="border border-gray-300 p-1"></td>
            </tr>
        ))}
    </tbody>
  </table>
);

const QuarterlyTable = ({ data, quarter }: { data: ClassRecord, quarter: 'q1'|'q2'|'q3'|'q4' }) => {
    // Styles matching the HTML provided (Green/Yellow themes)
    const headerColor = 'bg-[#d6e3bc]'; 
    
    return (
        <table className="w-full text-xs border-collapse min-w-[1500px]">
            <thead>
                <tr className="h-14">
                    <th className="border border-gray-400 bg-white p-1 sticky left-0 z-10 w-10"></th>
                    <th className="border border-gray-400 bg-white p-1 text-left font-bold text-lg min-w-[200px] sticky left-10 z-10 shadow-r">LEARNERS' NAMES</th>
                    <th className={`border border-gray-400 ${headerColor} p-1 font-bold w-12`}>ESP</th>
                    <th className={`border border-gray-400 ${headerColor} p-1 font-bold w-12`}>ENGLISH</th>
                    <th className={`border border-gray-400 ${headerColor} p-1 font-bold w-12`}>MATH</th>
                    <th className={`border border-gray-400 ${headerColor} p-1 font-bold w-12`}>SCIENCE</th>
                    <th className={`border border-gray-400 ${headerColor} p-1 font-bold w-12`}>FILIPINO</th>
                    <th className={`border border-gray-400 ${headerColor} p-1 font-bold w-12`}>AP</th>
                    <th className={`border border-gray-400 ${headerColor} p-1 font-bold w-12`}>EPP</th>
                    <th className={`border border-gray-400 ${headerColor} p-1 font-bold w-12`}>MAPEH</th>
                    <th className="border border-gray-400 bg-white p-1 font-bold w-12">MUSIC</th>
                    <th className="border border-gray-400 bg-white p-1 font-bold w-12">ARTS</th>
                    <th className="border border-gray-400 bg-white p-1 font-bold w-12">P.E.</th>
                    <th className="border border-gray-400 bg-white p-1 font-bold w-12">HEALTH</th>
                    <th className="border border-gray-400 bg-white p-1 font-bold w-16">AVERAGE</th>
                    <th className="border border-gray-400 bg-white p-1 font-bold w-12">RANK</th>
                </tr>
                <tr>
                    <th className="border border-gray-400 bg-white sticky left-0 z-10"></th>
                    <th className="border border-gray-400 bg-white sticky left-10 z-10 shadow-r"></th>
                    <th className="border border-gray-400 bg-[#d6e3bc]">1</th>
                    <th className="border border-gray-400 bg-[#d6e3bc]">2</th>
                    <th className="border border-gray-400 bg-[#d6e3bc]">3</th>
                    <th className="border border-gray-400 bg-[#d6e3bc]">4</th>
                    <th className="border border-gray-400 bg-[#d6e3bc]">5</th>
                    <th className="border border-gray-400 bg-[#d6e3bc]">6</th>
                    <th className="border border-gray-400 bg-[#d6e3bc]">7</th>
                    <th className="border border-gray-400 bg-[#d6e3bc]">8</th>
                    <th className="border border-gray-400 bg-white" colSpan={4}></th>
                    <th className="border border-gray-400 bg-white"></th>
                    <th className="border border-gray-400 bg-white"></th>
                </tr>
            </thead>
            <tbody>
                {/* Males */}
                {data.students.filter(s => s.sex === 'M').map((student, i) => (
                    <GradeRow key={student.studentId} student={student} index={i+1} q={quarter} />
                ))}
                {/* Spacer/Title for Females if needed, usually continuous in provided HTML but separated in logic */}
                <tr className="h-6"><td colSpan={16} className="border border-gray-400 bg-gray-200"></td></tr>
                {/* Females */}
                {data.students.filter(s => s.sex === 'F').map((student, i) => (
                    <GradeRow key={student.studentId} student={student} index={i+1} q={quarter} />
                ))}
            </tbody>
        </table>
    );
}

const GradeRow = ({ student, index, q }: { student: StudentFullYearGrades, index: number, q: 'q1'|'q2'|'q3'|'q4' }) => {
    const s = student.subjects;
    const m = student.mapeh;
    // Map 'q1' string to object key if needed, here simple lookup
    return (
        <tr>
            <td className="border border-gray-300 bg-[#ffff00] text-center p-1 font-bold sticky left-0 z-10">{index}</td>
            <td className="border border-gray-300 bg-[#ffff00] p-1 px-2 whitespace-nowrap sticky left-10 z-10 shadow-r">{student.studentName}</td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-[#ffff00] h-full focus:outline-none" defaultValue={s.ESP[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-[#ffff00] h-full focus:outline-none" defaultValue={s.ENGLISH[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-[#ffff00] h-full focus:outline-none" defaultValue={s.MATH[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-[#ffff00] h-full focus:outline-none" defaultValue={s.SCIENCE[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-[#ffff00] h-full focus:outline-none" defaultValue={s.FILIPINO[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-[#ffff00] h-full focus:outline-none" defaultValue={s.AP[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-[#ffff00] h-full focus:outline-none" defaultValue={s.EPP[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-[#ffff00] h-full focus:outline-none" defaultValue={s.MAPEH[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-white h-full focus:outline-none" defaultValue={m?.music[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-white h-full focus:outline-none" defaultValue={m?.arts[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-white h-full focus:outline-none" defaultValue={m?.pe[q]} /></td>
            <td className="border border-gray-300 text-center p-0"><input className="w-full text-center bg-white h-full focus:outline-none" defaultValue={m?.health[q]} /></td>
            <td className="border border-gray-300 text-center p-1 font-bold bg-[#ffff00]">{student.generalAverage?.[q]}</td>
            <td className="border border-gray-300 text-center p-1">{student.rank}</td>
        </tr>
    )
}

const FinalSummaryTable = ({ data }: { data: ClassRecord }) => (
    <table className="w-full text-[10px] border-collapse min-w-[2000px]">
        <thead>
            <tr>
                <th rowSpan={3} className="border border-black p-1 bg-white min-w-[200px] text-left sticky left-0 z-10 shadow-r">NAMES OF LEARNERS</th>
                {['FILIPINO', 'ENGLISH', 'MATHEMATICS', 'SCIENCE', 'AP', 'EPP', 'MAPEH', 'ESP'].map(sub => (
                    <th key={sub} colSpan={5} className="border border-black p-1 bg-white font-bold">{sub}</th>
                ))}
                <th rowSpan={3} className="border border-black p-1 bg-white">Gen. Average</th>
            </tr>
            <tr>
                {[1,2,3,4,5,6,7,8].map(i => (
                    <React.Fragment key={i}>
                        <th colSpan={4} className="border border-black p-1 bg-white">QUARTER</th>
                        <th rowSpan={2} className="border border-black p-1 bg-white font-bold w-10">FINAL</th>
                    </React.Fragment>
                ))}
            </tr>
            <tr>
                {[1,2,3,4,5,6,7,8].map(i => (
                    <React.Fragment key={i}>
                        <th className="border border-black p-1 w-6 bg-white">1</th>
                        <th className="border border-black p-1 w-6 bg-white">2</th>
                        <th className="border border-black p-1 w-6 bg-white">3</th>
                        <th className="border border-black p-1 w-6 bg-white">4</th>
                    </React.Fragment>
                ))}
            </tr>
        </thead>
        <tbody>
             <tr className="bg-white"><td colSpan={42} className="border border-black p-1 text-center font-bold text-xs sticky left-0 z-10 bg-[#d8d8d8] text-[#00b0f0]">MALE</td></tr>
             {data.students.filter(s => s.sex === 'M').map((s, i) => <FinalSummaryRow key={s.studentId} student={s} index={i+1} />)}
             <tr className="bg-white"><td colSpan={42} className="border border-black p-1 text-center font-bold text-xs sticky left-0 z-10 bg-[#d8d8d8] text-[#00b0f0]">FEMALE</td></tr>
             {data.students.filter(s => s.sex === 'F').map((s, i) => <FinalSummaryRow key={s.studentId} student={s} index={i+1} />)}
        </tbody>
    </table>
);

const FinalSummaryRow = ({ student, index }: { student: StudentFullYearGrades, index: number }) => {
    const subjects = ['FILIPINO', 'ENGLISH', 'MATH', 'SCIENCE', 'AP', 'EPP', 'MAPEH', 'ESP']; // Matches header order
    return (
        <tr>
            <td className="border border-black p-1 bg-white whitespace-nowrap px-2 sticky left-0 z-10 shadow-r">
                <span className="inline-block w-4 text-right mr-2">{index}</span>
                {student.studentName}
            </td>
            {subjects.map(sub => {
                const gr = student.subjects[sub] || {};
                return (
                    <React.Fragment key={sub}>
                        <td className="border border-black p-0 text-center"><input className="w-full text-center h-full text-[10px] focus:outline-none" defaultValue={gr.q1} /></td>
                        <td className="border border-black p-0 text-center"><input className="w-full text-center h-full text-[10px] focus:outline-none" defaultValue={gr.q2} /></td>
                        <td className="border border-black p-0 text-center"><input className="w-full text-center h-full text-[10px] focus:outline-none" defaultValue={gr.q3} /></td>
                        <td className="border border-black p-0 text-center"><input className="w-full text-center h-full text-[10px] focus:outline-none" defaultValue={gr.q4} /></td>
                        <td className="border border-black p-0 text-center font-bold bg-gray-50">{gr.final}</td>
                    </React.Fragment>
                )
            })}
            <td className="border border-black p-1 text-center font-bold">{student.generalAverage?.final}</td>
        </tr>
    );
}

export default GradingSheet;