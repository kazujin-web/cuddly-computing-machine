import React, { useState } from 'react';
import Layout from './components/Layout';
import SF9ReportCard from './components/SF9ReportCard';
import IDGenerator from './components/IDGenerator';
import GradingSheet from './components/GradingSheet';
import { mockSF9Data, mockStudent } from './services/mockData';
import { Role } from './types';

const App: React.FC = () => {
  const [role, setRole] = useState<Role>(Role.STUDENT);
  const [currentView, setView] = useState<string>('sf9');

  const renderContent = () => {
    // Determine default view based on role switch
    if (role === Role.STUDENT) {
        if (currentView === 'grading' || currentView === 'masterlist') {
            setView('sf9'); // Reset if invalid for role
            return null;
        }
        
        switch (currentView) {
            case 'sf9':
                return <SF9ReportCard data={mockSF9Data} />;
            case 'id':
                return <IDGenerator student={mockStudent} />;
            default:
                return <SF9ReportCard data={mockSF9Data} />;
        }
    } else {
        if (currentView === 'sf9' || currentView === 'id') {
            setView('grading'); // Reset if invalid for role
            return null;
        }

        switch (currentView) {
            case 'grading':
                return <GradingSheet />;
            case 'masterlist':
                return (
                    <div className="p-6 bg-white rounded-lg shadow-sm">
                        <h2 className="text-2xl font-bold mb-4">Masterlist Management</h2>
                        <p className="text-gray-500">Feature to export student list to Google Sheets.</p>
                        <div className="mt-4 p-4 border border-dashed border-gray-300 rounded text-center">
                            <p className="text-sm text-gray-400">Masterlist table placeholder</p>
                        </div>
                    </div>
                );
            default:
                return <GradingSheet />;
        }
    }
  };

  return (
    <Layout role={role} setRole={setRole} currentView={currentView} setView={setView}>
      {renderContent()}
    </Layout>
  );
};

export default App;