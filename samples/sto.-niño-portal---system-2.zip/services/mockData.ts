import { SF9Data, Student, ClassRecord } from '../types';

export const mockStudent: Student = {
  lrn: "123456789012",
  name: "Carlo Dela Cruz",
  gradeLevel: "FIVE",
  section: "RIZAL",
  gender: "MALE",
  age: 10,
  photoUrl: "https://picsum.photos/200/200"
};

export const mockSF9Data: SF9Data = {
  student: mockStudent,
  schoolYear: "2025-2026",
  grades: [
    { subject: "Filipino", q1: 77, q2: 78, q3: 84, q4: 84, final: 81, remarks: "Passed" },
    { subject: "English", q1: 78, q2: 80, q3: 80, q4: 80, final: 80, remarks: "Passed" },
    { subject: "Mathematics", q1: 79, q2: 80, q3: 78, q4: 81, final: 80, remarks: "Passed" },
    { subject: "Science", q1: 77, q2: 80, q3: 77, q4: 81, final: 79, remarks: "Passed" },
    { subject: "Araling Panlipunan (AP)", q1: 80, q2: 81, q3: 81, q4: 83, final: 81, remarks: "Passed" },
    { subject: "Edukasyon sa Pagpapakatao (EsP)", q1: 81, q2: 84, q3: 85, q4: 87, final: 84, remarks: "Passed" },
    { subject: "Edukasyong Pantahanan (EPP)", q1: 84, q2: 85, q3: 86, q4: 88, final: 86, remarks: "Passed" },
    { subject: "MAPEH", q1: 84, q2: 85, q3: 84, q4: 86, final: 85, remarks: "Passed" },
    { subject: "Music", q1: 84, q2: 84, q3: 83, q4: 85, final: 84, remarks: "Passed" },
    { subject: "Arts", q1: 84, q2: 84, q3: 83, q4: 85, final: 84, remarks: "Passed" },
    { subject: "PE", q1: 84, q2: 85, q3: 84, q4: 86, final: 85, remarks: "Passed" },
    { subject: "Health", q1: 84, q2: 85, q3: 84, q4: 86, final: 85, remarks: "Passed" },
  ],
  attendance: [
    { month: "June", schoolDays: 10, daysPresent: 9, daysAbsent: 1 },
    { month: "July", schoolDays: 10, daysPresent: 8, daysAbsent: 2 },
    { month: "Aug", schoolDays: 10, daysPresent: 10, daysAbsent: 0 },
    { month: "Sept", schoolDays: 10, daysPresent: 9, daysAbsent: 1 },
    { month: "Oct", schoolDays: 10, daysPresent: 9, daysAbsent: 1 },
    { month: "Nov", schoolDays: 10, daysPresent: 10, daysAbsent: 0 },
    { month: "Dec", schoolDays: 10, daysPresent: 9, daysAbsent: 1 },
    { month: "Jan", schoolDays: 10, daysPresent: 8, daysAbsent: 2 },
    { month: "Feb", schoolDays: 10, daysPresent: 9, daysAbsent: 1 },
    { month: "Mar", schoolDays: 10, daysPresent: 9, daysAbsent: 1 },
  ],
  values: [
    { value: "Maka-Diyos", behaviorStatements: ["Expresses one's spiritual beliefs while respecting the spiritual beliefs of others."], q1: "AO", q2: "AO", q3: "AO", q4: "AO" },
    { value: "Maka-Tao", behaviorStatements: ["Shows adherence to ethical principles by upholding truth", "Is sensitive to individual, social and cultural differences", "Demonstrates contributions toward solidarity"], q1: "AO", q2: "AO", q3: "AO", q4: "AO" },
    { value: "Maka-Kalikasan", behaviorStatements: ["Cares for the environment and utilizes resources wisely, judiciously, and economically"], q1: "AO", q2: "AO", q3: "AO", q4: "AO" },
    { value: "Maka-Bansa", behaviorStatements: ["Demonstrates pride in being a Filipino; exercises the rights and responsibilities of a Filipino citizen", "Demonstrates appropriate behavior in carrying out activities in the school, community, and country"], q1: "AO", q2: "AO", q3: "AO", q4: "AO" },
  ],
  generalAverage: 82
};

const generateStudent = (id: string, name: string, sex: 'M' | 'F') => ({
  studentId: id,
  studentName: name,
  sex,
  lrn: "123456789012",
  age: 10,
  subjects: {
    ESP: { q1: 85, q2: 86, q3: 84, q4: 85, final: 85 },
    ENGLISH: { q1: 81, q2: 82, q3: 81, q4: 82, final: 81.5 },
    MATH: { q1: 81, q2: 81, q3: 82, q4: 81, final: 81.25 },
    SCIENCE: { q1: 80, q2: 81, q3: 80, q4: 81, final: 80.5 },
    FILIPINO: { q1: 81, q2: 81, q3: 80, q4: 81, final: 80.75 },
    AP: { q1: 87, q2: 84, q3: 82, q4: 84, final: 84.25 },
    EPP: { q1: 90, q2: 88, q3: 85, q4: 88, final: 87.75 },
    MAPEH: { q1: 86, q2: 84, q3: 85, q4: 86, final: 85.25 }
  },
  mapeh: {
    music: { q1: 87, q2: 84, q3: 84, q4: 85, final: 85 },
    arts: { q1: 85, q2: 84, q3: 85, q4: 86, final: 85 },
    pe: { q1: 85, q2: 84, q3: 85, q4: 86, final: 85 },
    health: { q1: 86, q2: 84, q3: 85, q4: 86, final: 85.25 }
  },
  generalAverage: { q1: 84, q2: 83, q3: 82, q4: 84, final: 83.25 },
  rank: 1
});

export const mockClassRecord: ClassRecord = {
  section: "RIZAL",
  gradeLevel: "FIVE",
  schoolYear: "2025-2026",
  students: [
    generateStudent("1", "Antonio Reyes", "M"),
    generateStudent("2", "Carlo Dela Cruz", "M"),
    generateStudent("3", "Daniel Bautista", "M"),
    generateStudent("4", "Ernesto Garcia", "M"),
    generateStudent("5", "Joseph Mendoza", "M"),
    generateStudent("6", "Luis Fernandez", "M"),
    generateStudent("7", "Miguel Santos", "M"),
    generateStudent("8", "Paolo Navarro", "M"),
    generateStudent("9", "Rafael Castillo", "M"),
    generateStudent("10", "Ramon Villanueva", "M"),
  ]
};